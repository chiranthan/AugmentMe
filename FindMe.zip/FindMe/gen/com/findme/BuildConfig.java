/** Automatically generated file. DO NOT MODIFY */
package com.findme;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}